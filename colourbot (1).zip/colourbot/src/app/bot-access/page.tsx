import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import BotAccessHero from './components/BotAccessHero';
import BotStatusPanel from './components/BotStatusPanel';
import AccessLinks from './components/AccessLinks';
import AccessInstructions from './components/AccessInstructions';

export default function BotAccessPage() {
  return (
    <main className="min-h-screen bg-[#080B14] overflow-x-hidden">
      <Header />
      <BotAccessHero />
      <BotStatusPanel />
      <AccessLinks />
      <AccessInstructions />
      <Footer />
    </main>
  );
}