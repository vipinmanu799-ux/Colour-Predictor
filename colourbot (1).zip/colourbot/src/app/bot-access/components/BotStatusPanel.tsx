'use client';

import React, { useState, useEffect } from 'react';

const METRICS = [
  { label: 'Bot Uptime', value: '99.8%', colour: '#00FF88' },
  { label: 'Predictions Today', value: '2,847', colour: '#00D4FF' },
  { label: 'Active Sessions', value: '1,204', colour: '#A75CFF' },
  { label: 'Avg Confidence', value: '88.3%', colour: '#FFB800' },
];

export default function BotStatusPanel() {
  const [currentTime, setCurrentTime] = useState('');
  const [countdown, setCountdown] = useState(28);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        `${String(now?.getHours())?.padStart(2,'0')}:${String(now?.getMinutes())?.padStart(2,'0')}:${String(now?.getSeconds())?.padStart(2,'0')}`
      );
    };
    updateTime();
    const t = setInterval(updateTime, 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const c = setInterval(() => {
      setCountdown((v) => (v <= 1 ? 30 : v - 1));
    }, 1000);
    return () => clearInterval(c);
  }, []);

  return (
    <section className="py-8 px-4 sm:px-6">
      <div className="max-w-5xl mx-auto">
        {/* Status bar */}
        <div className="glass-dark rounded-2xl border border-[#00FF88]/20 p-5 mb-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#00FF88]/15 border border-[#00FF88]/30 flex items-center justify-center">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00FF88] opacity-75" />
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-[#00FF88]" />
                </span>
              </div>
              <div>
                <p className="text-sm font-bold text-white">ColourBot System Status</p>
                <p className="text-xs text-[#00FF88] font-semibold">● ONLINE — All Systems Operational</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-xs text-[#6B7280]">Server Time</p>
                <p className="text-sm font-bold text-white font-mono">{currentTime}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-[#6B7280]">Next Signal</p>
                <p className="text-sm font-bold text-[#00D4FF] font-mono">{countdown < 10 ? `0${countdown}` : countdown}s</p>
              </div>
            </div>
          </div>
        </div>

        {/* Metrics row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {METRICS?.map((m) => (
            <div key={m?.label} className="glass-dark rounded-xl p-4 border border-[#1E2A3A] text-center">
              <p className="text-2xl font-extrabold font-mono mb-1" style={{ color: m?.colour }}>{m?.value}</p>
              <p className="text-xs text-[#6B7280] font-medium">{m?.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}