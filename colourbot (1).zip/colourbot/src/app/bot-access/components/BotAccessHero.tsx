import React from 'react';

export default function BotAccessHero() {
  return (
    <section className="relative pt-32 pb-12 px-4 sm:px-6 overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-[#00FF88]/6 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute top-0 right-0 w-[400px] h-[300px] bg-[#00D4FF]/4 blur-[100px] rounded-full pointer-events-none" />

      <div className="max-w-4xl mx-auto text-center relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass-dark border border-[#00FF88]/25 mb-6">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00FF88] opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#00FF88]" />
          </span>
          <span className="text-xs font-bold text-[#00FF88] uppercase tracking-widest">Bot Active — Access Available</span>
        </div>

        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.0] mb-6">
          Get <span className="neon-green">ColourBot</span> Access
        </h1>
        <p className="text-[#6B7280] text-lg leading-relaxed max-w-2xl mx-auto">
          Tap the button below to open the ColourBot prediction panel. The bot is live 24/7 — start receiving colour and number signals instantly.
        </p>
      </div>
    </section>
  );
}