import React from 'react';
import Link from 'next/link';

const STEPS = [
  { n: '1', text: 'Click "Open Bot Panel" above to launch ColourBot in your browser.' },
  { n: '2', text: 'Wait for the bot to load — it shows the current colour/number prediction immediately.' },
  { n: '3', text: 'Note the predicted colour (Red/Green/Violet), number (0–9), and confidence score.' },
  { n: '4', text: 'Open your colour trading platform in another tab and place your bet matching the signal.' },
  { n: '5', text: 'Return to ColourBot after the round and check the result. Repeat each 30-second cycle.' },
];

export default function AccessInstructions() {
  return (
    <section className="py-12 px-4 sm:px-6 pb-20">
      <div className="max-w-5xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">

          {/* Instructions */}
          <div className="glass-dark rounded-2xl p-6 border border-[#1E2A3A]">
            <h3 className="text-lg font-bold text-white mb-5 flex items-center gap-2">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#00FF88" strokeWidth="2.5">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
              </svg>
              Quick Start Instructions
            </h3>
            <div className="flex flex-col gap-4">
              {STEPS?.map((s) => (
                <div key={s?.n} className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-lg bg-[#00FF88]/15 border border-[#00FF88]/30 text-[#00FF88] text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                    {s?.n}
                  </span>
                  <p className="text-sm text-[#6B7280] leading-relaxed">{s?.text}</p>
                </div>
              ))}
            </div>
          </div>

          {/* CTA + support */}
          <div className="flex flex-col gap-5">
            {/* Main CTA */}
            <div className="relative rounded-2xl overflow-hidden p-6 glass-dark border border-[#00FF88]/25 text-center">
              <div className="absolute inset-0 -z-10">
                <div className="absolute inset-0 bg-gradient-to-br from-[#00FF88]/5 to-transparent" />
              </div>
              <div className="text-3xl mb-3">🤖</div>
              <h3 className="text-lg font-bold text-white mb-2">ColourBot is Ready</h3>
              <p className="text-sm text-[#6B7280] mb-5">The bot is online and predictions are updating live. Access it now and start trading smarter.</p>
              <a
                href="#"
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full py-3.5 rounded-xl text-base font-bold text-[#080B14] bg-[#00FF88] hover:bg-[#00FF88]/90 transition-all animate-neon-pulse"
              >
                Launch ColourBot →
              </a>
            </div>

            {/* Need help */}
            <div className="glass-dark rounded-2xl p-5 border border-[#1E2A3A]">
              <h4 className="text-sm font-bold text-white mb-3">Need Help?</h4>
              <p className="text-xs text-[#6B7280] leading-relaxed mb-4">
                First time using ColourBot? Read the complete guide to understand how to read signals and place winning trades.
              </p>
              <Link
                href="/guide"
                className="inline-flex items-center gap-2 text-sm font-semibold text-[#00D4FF] hover:text-white transition-colors"
              >
                Read the Full Guide →
              </Link>
            </div>

            {/* Disclaimer */}
            <div className="p-4 rounded-xl border border-[#FF3366]/20 bg-[#FF3366]/5">
              <p className="text-xs text-[#6B7280] leading-relaxed">
                <span className="text-[#FF3366] font-semibold">⚠ Disclaimer:</span> ColourBot provides signals for entertainment. Colour trading involves financial risk. Trade responsibly.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}