'use client';

import React, { useState } from 'react';

const ACCESS_OPTIONS = [
  {
    id: 'web',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="2" y="3" width="20" height="14" rx="2" /><path d="M8 21h8M12 17v4" />
      </svg>
    ),
    title: 'Web Bot Panel',
    description: 'Open ColourBot directly in your browser. Works on all devices — no download needed.',
    badge: 'RECOMMENDED',
    badgeColour: '#00FF88',
    buttonText: 'Open Bot Panel →',
    buttonStyle: 'bg-[#00FF88] text-[#080B14] animate-neon-pulse',
    colour: '#00FF88',
    href: 'https://www.jaiclub99.com/#/register?invitationCode=33273184018',
  },
  {
    id: 'telegram',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M21.73 2.27a2 2 0 0 0-2.12-.46L2.41 8.46a2 2 0 0 0 .08 3.76l4.51 1.5 1.5 4.51a2 2 0 0 0 3.76.08l6.65-17.2a2 2 0 0 0-.46-2.12z" />
      </svg>
    ),
    title: 'Telegram Bot',
    description: 'Join the ColourBot Telegram channel for signal alerts sent directly to your phone.',
    badge: 'INSTANT ALERTS',
    badgeColour: '#00D4FF',
    buttonText: 'Join Telegram →',
    buttonStyle: 'border border-[#00D4FF]/40 text-[#00D4FF] hover:bg-[#00D4FF]/10',
    colour: '#00D4FF',
    href: '#',
  },
  {
    id: 'whatsapp',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
      </svg>
    ),
    title: 'WhatsApp Group',
    description: 'Join the ColourBot WhatsApp group for community signals and real-time prediction sharing.',
    badge: 'COMMUNITY',
    badgeColour: '#A75CFF',
    buttonText: 'Join WhatsApp →',
    buttonStyle: 'border border-[#A75CFF]/40 text-[#A75CFF] hover:bg-[#A75CFF]/10',
    colour: '#A75CFF',
    href: '#',
  },
];

export default function AccessLinks() {
  const [clicked, setClicked] = useState<string | null>(null);

  const handleClick = (id: string) => {
    setClicked(id);
    setTimeout(() => setClicked(null), 2000);
  };

  return (
    <section className="py-12 px-4 sm:px-6">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Choose Your Access Method</h2>
          <p className="text-[#6B7280] mt-2 text-sm">Pick the option that works best for you. All methods provide the same real-time predictions.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          {ACCESS_OPTIONS.map((opt) => (
            <div
              key={opt.id}
              className="glass-dark rounded-2xl p-6 border border-[#1E2A3A] hover:border-opacity-60 transition-all duration-300 flex flex-col"
              style={{ '--hover-border': `${opt.colour}40` } as React.CSSProperties}
            >
              {/* Icon */}
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                style={{ background: `${opt.colour}15`, color: opt.colour, border: `1px solid ${opt.colour}30` }}
              >
                {opt.icon}
              </div>

              {/* Badge */}
              <div className="mb-3">
                <span
                  className="text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-md"
                  style={{ color: opt.badgeColour, background: `${opt.badgeColour}15`, border: `1px solid ${opt.badgeColour}30` }}
                >
                  {opt.badge}
                </span>
              </div>

              <h3 className="text-base font-bold text-white mb-2">{opt.title}</h3>
              <p className="text-sm text-[#6B7280] leading-relaxed flex-1 mb-5">{opt.description}</p>

              <a
                href={opt.href}
                onClick={() => handleClick(opt.id)}
                className={`w-full py-3 rounded-xl text-sm font-bold text-center transition-all duration-200 block ${opt.buttonStyle}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                {clicked === opt.id ? '✓ Opening...' : opt.buttonText}
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}