import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import GuideHero from './components/GuideHero';
import StepsSection from './components/StepsSection';
import TipsSection from './components/TipsSection';
import GuideFAQ from './components/GuideFAQ';

export default function GuidePage() {
  return (
    <main className="min-h-screen bg-[#080B14] overflow-x-hidden">
      <Header />
      <GuideHero />
      <StepsSection />
      <TipsSection />
      <GuideFAQ />
      <Footer />
    </main>
  );
}