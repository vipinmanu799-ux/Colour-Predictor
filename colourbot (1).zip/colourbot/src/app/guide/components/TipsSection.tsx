import React from 'react';

const TIPS = [
  {
    icon: '🎯',
    title: 'Wait for 85%+ Confidence',
    description: 'Only place trades when the bot shows 85% or higher confidence score. Lower scores mean weaker signals.',
    colour: '#00FF88',
  },
  {
    icon: '💰',
    title: 'Use 5–10% Bet Size',
    description: 'Never risk more than 10% of your balance on a single round. Consistent small wins beat big risky bets.',
    colour: '#00D4FF',
  },
  {
    icon: '⏱️',
    title: 'Trade During Peak Hours',
    description: 'Bot accuracy is highest between 8 AM–12 PM and 6 PM–10 PM when trading volume is at its peak.',
    colour: '#A75CFF',
  },
  {
    icon: '🔄',
    title: 'Follow 3-Loss Rule',
    description: 'If you lose 3 consecutive rounds, stop for at least 30 minutes. Pattern cycles reset frequently.',
    colour: '#FF3366',
  },
  {
    icon: '📊',
    title: 'Track Your Results',
    description: 'Keep a simple log of your trades. Tracking helps you identify which colour signals work best for you.',
    colour: '#FFB800',
  },
  {
    icon: '🔔',
    title: 'Refresh Before Each Round',
    description: 'Always refresh the bot panel before placing a trade. Predictions update every 30 seconds.',
    colour: '#00FF88',
  },
];

export default function TipsSection() {
  return (
    <section className="py-16 px-4 sm:px-6 bg-[#080B14]">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <span className="text-xs font-bold text-[#FF3366] uppercase tracking-widest block mb-3">Pro Tips</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Win More, Lose Less
          </h2>
          <p className="text-[#6B7280] mt-3 max-w-xl mx-auto">
            These strategies separate consistent winners from casual players.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {TIPS?.map((tip, i) => (
            <div
              key={i}
              className="glass-dark rounded-2xl p-5 border border-[#1E2A3A] hover:border-[#00FF88]/20 transition-all duration-300 group"
            >
              <div className="text-2xl mb-3">{tip?.icon}</div>
              <h3 className="text-base font-bold text-white mb-2 group-hover:text-[#00FF88] transition-colors">{tip?.title}</h3>
              <p className="text-sm text-[#6B7280] leading-relaxed">{tip?.description}</p>
            </div>
          ))}
        </div>

        {/* Warning card */}
        <div className="mt-8 p-5 rounded-2xl border border-[#FF3366]/30 bg-[#FF3366]/5">
          <div className="flex items-start gap-3">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#FF3366" strokeWidth="2.5" className="flex-shrink-0 mt-0.5">
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" /><line x1="12" y1="9" x2="12" y2="13" /><line x1="12" y1="17" x2="12.01" y2="17" />
            </svg>
            <div>
              <p className="text-sm font-bold text-[#FF3366] mb-1">Responsible Trading Disclaimer</p>
              <p className="text-xs text-[#6B7280] leading-relaxed">
                ColourBot provides prediction signals for entertainment purposes. Colour trading involves financial risk. Never trade with money you cannot afford to lose. Past prediction accuracy does not guarantee future results.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}