import React from 'react';
import Link from 'next/link';

export default function GuideHero() {
  return (
    <section className="relative pt-32 pb-16 px-4 sm:px-6 overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-[#00FF88]/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-4xl mx-auto text-center relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass-dark border border-[#00D4FF]/20 mb-6">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#00D4FF" strokeWidth="2.5">
            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
          </svg>
          <span className="text-xs font-bold text-[#00D4FF] uppercase tracking-widest">Complete Guide</span>
        </div>

        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.0] mb-6">
          How to Use <span className="neon-green">ColourBot</span>
        </h1>
        <p className="text-[#6B7280] text-lg leading-relaxed max-w-2xl mx-auto mb-8">
          From first login to your first winning trade — follow this step-by-step guide to get the most out of ColourBot's prediction system.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link
            href="/bot-access"
            className="px-7 py-3.5 rounded-xl text-base font-bold text-[#080B14] bg-[#00FF88] hover:bg-[#00FF88]/90 transition-all animate-neon-pulse"
          >
            Access Bot Now →
          </Link>
          <a
            href="#steps"
            className="px-7 py-3.5 rounded-xl text-base font-bold text-white border border-[#1E2A3A] hover:border-[#00FF88]/40 hover:bg-[#00FF88]/5 transition-all"
          >
            Start Reading ↓
          </a>
        </div>
      </div>
    </section>
  );
}