'use client';

import React, { useRef, useState, useEffect } from 'react';

interface Step {
  number: string;
  title: string;
  description: string;
  detail: string;
  colour: string;
  icon: React.ReactNode;
  mockup: {
    label: string;
    lines: { text: string; colour: string }[];
  };
}

const STEPS: Step[] = [
  {
    number: '01',
    title: 'Register on the Trading Platform',
    description: 'Create your account on the colour trading platform. Use the referral link from the Bot Access page for bonus credits.',
    detail: 'Takes less than 2 minutes. You\'ll need a phone number and basic details to verify your account.',
    colour: '#00FF88',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
      </svg>
    ),
    mockup: {
      label: 'Platform Registration',
      lines: [
        { text: '✓ Phone verified', colour: '#00FF88' },
        { text: '✓ Account created', colour: '#00FF88' },
        { text: '→ Bonus credited: ₹50', colour: '#00D4FF' },
      ],
    },
  },
  {
    number: '02',
    title: 'Open the Bot Prediction Panel',
    description: 'Navigate to the Bot Access page and open the ColourBot prediction link. The bot runs 24/7 and updates every 30 seconds.',
    detail: 'No app download required. The bot works directly in your browser on any device.',
    colour: '#00D4FF',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="2" y="3" width="20" height="14" rx="2" /><path d="M8 21h8M12 17v4" />
      </svg>
    ),
    mockup: {
      label: 'ColourBot Panel',
      lines: [
        { text: '⬤ Bot Status: ONLINE', colour: '#00FF88' },
        { text: '⬤ Signal Ready', colour: '#00FF88' },
        { text: '⬤ Next update: 28s', colour: '#00D4FF' },
      ],
    },
  },
  {
    number: '03',
    title: 'Read the Colour & Number Signal',
    description: 'The bot displays the predicted colour (Red/Green/Violet) and number (0–9) with a confidence score. Higher confidence = stronger signal.',
    detail: 'Signals above 85% confidence are considered strong. Wait for high-confidence signals for best results.',
    colour: '#A75CFF',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="12" cy="12" r="10" /><path d="M12 8v4l3 3" />
      </svg>
    ),
    mockup: {
      label: 'Current Signal',
      lines: [
        { text: '▶ Number: 7', colour: '#FF3366' },
        { text: '▶ Colour: RED', colour: '#FF3366' },
        { text: '▶ Confidence: 92%', colour: '#00FF88' },
      ],
    },
  },
  {
    number: '04',
    title: 'Place Your Trade',
    description: 'Switch to the trading platform and place your bet matching the bot\'s prediction. Start small to understand the pattern before scaling up.',
    detail: 'Recommended bet size: 5–10% of your balance per round. Never bet more than you can afford to lose.',
    colour: '#FF3366',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" /><polyline points="16 7 22 7 22 13" />
      </svg>
    ),
    mockup: {
      label: 'Trade Placed',
      lines: [
        { text: '✓ Bet: RED — ₹100', colour: '#FF3366' },
        { text: '✓ Round: #48291', colour: '#6B7280' },
        { text: '→ Result: WIN +₹190', colour: '#00FF88' },
      ],
    },
  },
];

export default function StepsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => { if (entries[0].isIntersecting) { setVisible(true); observer.disconnect(); } },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="steps" ref={sectionRef} className="py-16 px-4 sm:px-6 bg-[#0D1220]">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">4 Steps to Your First Win</h2>
          <p className="text-[#6B7280] mt-3 max-w-xl mx-auto">Follow each step exactly and you'll be placing informed trades within minutes.</p>
        </div>

        <div className="flex flex-col gap-8">
          {STEPS.map((step, i) => (
            <div
              key={step.number}
              className={`grid grid-cols-1 lg:grid-cols-2 gap-6 items-center ${visible ? 'animate-slide-in-up opacity-100' : 'opacity-100'}`}
              style={visible ? { animationDelay: `${i * 0.15}s` } : {}}
            >
              {/* Left: Content */}
              <div className={`${i % 2 === 1 ? 'lg:order-2' : ''}`}>
                <div className="glass-dark rounded-2xl p-6 border border-[#1E2A3A] hover:border-opacity-60 transition-all duration-300">
                  <div className="flex items-start gap-4">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ background: `${step.colour}20`, color: step.colour, border: `1px solid ${step.colour}40` }}
                    >
                      {step.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-xs font-bold font-mono" style={{ color: step.colour }}>STEP {step.number}</span>
                      </div>
                      <h3 className="text-xl font-bold text-white mb-3">{step.title}</h3>
                      <p className="text-[#6B7280] text-sm leading-relaxed mb-3">{step.description}</p>
                      <div className="flex items-start gap-2 p-3 rounded-lg bg-[#080B14] border border-[#1E2A3A]">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#00D4FF" strokeWidth="2.5" className="mt-0.5 flex-shrink-0">
                          <circle cx="12" cy="12" r="10" /><path d="M12 16v-4M12 8h.01" />
                        </svg>
                        <p className="text-xs text-[#6B7280] leading-relaxed">{step.detail}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right: Mockup card */}
              <div className={`${i % 2 === 1 ? 'lg:order-1' : ''}`}>
                <div
                  className="glass-dark rounded-2xl p-5 border"
                  style={{ borderColor: `${step.colour}30` }}
                >
                  <div className="flex items-center gap-2 mb-4">
                    <div className="flex gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#FF3366]/60" />
                      <span className="w-2.5 h-2.5 rounded-full bg-[#FFB800]/60" />
                      <span className="w-2.5 h-2.5 rounded-full bg-[#00FF88]/60" />
                    </div>
                    <span className="text-xs font-mono text-[#6B7280]">{step.mockup.label}</span>
                  </div>
                  <div className="bg-[#080B14] rounded-xl p-4 font-mono">
                    {step.mockup.lines.map((line, j) => (
                      <div key={j} className="text-sm py-1.5" style={{ color: line.colour }}>
                        {line.text}
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    <span className="relative flex h-1.5 w-1.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" style={{ background: step.colour }} />
                      <span className="relative inline-flex rounded-full h-1.5 w-1.5" style={{ background: step.colour }} />
                    </span>
                    <span className="text-xs text-[#6B7280]">Live example</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}