'use client';

import React, { useState } from 'react';

const FAQS = [
  {
    q: 'Is ColourBot free to use?',
    a: 'Yes, ColourBot\'s prediction display is completely free. Simply access the bot link and start using predictions immediately with no subscription required.',
  },
  {
    q: 'How often does the bot update predictions?',
    a: 'ColourBot updates its prediction signal every 30 seconds, aligned with the standard colour trading game round intervals. Always refresh before placing a trade.',
  },
  {
    q: 'What does the confidence score mean?',
    a: 'The confidence score (0–100%) represents how strong the current pattern signal is. Scores above 85% indicate a strong signal. Below 75% means the pattern is weak — consider skipping that round.',
  },
  {
    q: 'Which colour trading platform works with ColourBot?',
    a: 'ColourBot is designed for the most popular colour trading game platforms. Use the referral link on the Bot Access page to register on the recommended platform.',
  },
  {
    q: 'Can I use ColourBot on mobile?',
    a: 'Absolutely. ColourBot works on any device — phone, tablet, or desktop. No app download required. Open the bot link in your mobile browser.',
  },
  {
    q: 'Why did the bot prediction lose?',
    a: 'No prediction system is 100% accurate. ColourBot operates at a 91.4% win rate over time, but individual rounds can still lose. Follow the 3-loss rule and bet conservatively.',
  },
];

export default function GuideFAQ() {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  return (
    <section className="py-16 px-4 sm:px-6 bg-[#0D1220]">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">Frequently Asked Questions</h2>
          <p className="text-[#6B7280] mt-3">Everything you need to know before you start.</p>
        </div>

        <div className="flex flex-col gap-3">
          {FAQS?.map((faq, i) => (
            <div
              key={i}
              className={`glass-dark rounded-xl border transition-all duration-300 ${openIdx === i ? 'border-[#00FF88]/30' : 'border-[#1E2A3A]'}`}
            >
              <button
                className="w-full flex items-center justify-between p-5 text-left"
                onClick={() => setOpenIdx(openIdx === i ? null : i)}
              >
                <span className={`text-sm font-semibold transition-colors ${openIdx === i ? 'text-[#00FF88]' : 'text-white'}`}>
                  {faq?.q}
                </span>
                <svg
                  width="16" height="16" viewBox="0 0 24 24" fill="none"
                  stroke={openIdx === i ? '#00FF88' : '#6B7280'} strokeWidth="2.5"
                  className={`flex-shrink-0 ml-4 transition-transform duration-300 ${openIdx === i ? 'rotate-180' : ''}`}
                >
                  <path d="M6 9l6 6 6-6" />
                </svg>
              </button>
              {openIdx === i && (
                <div className="px-5 pb-5 animate-slide-in-up">
                  <p className="text-sm text-[#6B7280] leading-relaxed">{faq?.a}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}