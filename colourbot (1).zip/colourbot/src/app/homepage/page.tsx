import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HeroSection from './components/HeroSection';
import LivePredictions from './components/LivePredictions';
import StatsSection from './components/StatsSection';
import HomeCTA from './components/HomeCTA';

export default function HomepagePage() {
  return (
    <main className="min-h-screen bg-[#080B14] overflow-x-hidden">
      <Header />
      <HeroSection />
      <LivePredictions />
      <StatsSection />
      <HomeCTA />
      <Footer />
    </main>
  );
}