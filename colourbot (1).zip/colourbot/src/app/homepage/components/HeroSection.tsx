'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AppImage from '@/components/ui/AppImage';

const PREDICTIONS = [
{ number: 3, colour: 'GREEN', confidence: 87 },
{ number: 7, colour: 'RED', confidence: 92 },
{ number: 0, colour: 'VIOLET', confidence: 78 },
{ number: 5, colour: 'GREEN', confidence: 84 },
{ number: 8, colour: 'RED', confidence: 91 },
{ number: 1, colour: 'VIOLET', confidence: 76 }];


const HISTORY = [
{ number: 4, colour: 'RED', result: 'WIN', time: '08:31' },
{ number: 2, colour: 'GREEN', result: 'WIN', time: '08:29' },
{ number: 9, colour: 'RED', result: 'LOSS', time: '08:27' },
{ number: 0, colour: 'VIOLET', result: 'WIN', time: '08:25' },
{ number: 6, colour: 'GREEN', result: 'WIN', time: '08:23' }];


const colourClass: Record<string, string> = {
  GREEN: 'prediction-green',
  RED: 'prediction-red',
  VIOLET: 'prediction-violet'
};

const colourDot: Record<string, string> = {
  GREEN: 'bg-[#00FF88]',
  RED: 'bg-[#FF3366]',
  VIOLET: 'bg-[#A75CFF]'
};

export default function HeroSection() {
  const [predIdx, setPredIdx] = useState(0);
  const [ticking, setTicking] = useState(false);
  const [countdown, setCountdown] = useState(30);

  useEffect(() => {
    const interval = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          setTicking(true);
          setTimeout(() => {
            setPredIdx((i) => (i + 1) % PREDICTIONS.length);
            setTicking(false);
          }, 400);
          return 30;
        }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const current = PREDICTIONS[predIdx];

  return (
    <section className="relative min-h-screen flex items-center pt-16 overflow-hidden">
      {/* Background layers */}
      <div className="absolute inset-0 z-0">
        <AppImage
          src="https://images.unsplash.com/photo-1555748318-4a7451fff295"
          alt="Dark circuit board technology background with dim atmospheric lighting, deep shadows, near-black tones"
          fill
          className="object-cover opacity-10"
          priority />

        <div className="absolute inset-0 bg-gradient-to-br from-[#080B14] via-[#080B14]/95 to-[#0D1220]" />
        {/* Neon glow blobs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#00FF88]/5 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-[#00D4FF]/5 rounded-full blur-[100px] pointer-events-none" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 w-full py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          {/* Left: Copy */}
          <div className="flex flex-col gap-6">
            {/* Status badge */}
            <div className="inline-flex items-center gap-2 self-start px-3 py-1.5 rounded-full glass-dark border border-[#00FF88]/20">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00FF88] opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#00FF88]" />
              </span>
              <span className="text-xs font-semibold text-[#00FF88] tracking-widest uppercase">Bot Online — Live Predictions</span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight leading-[0.95]">
              <span className="text-white">Predict.</span>
              <br />
              <span className="neon-green">Win.</span>
              <br />
              <span className="text-white opacity-60">Repeat.</span>
            </h1>

            <p className="text-[#6B7280] text-lg leading-relaxed max-w-lg font-medium">
              ColourBot delivers real-time colour and number predictions with high-accuracy signals. Stop guessing — start winning with data-driven bot intelligence.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 mt-2">
              <Link
                href="/bot-access"
                className="px-7 py-3.5 rounded-xl text-base font-bold text-[#080B14] bg-[#00FF88] hover:bg-[#00FF88]/90 transition-all duration-200 animate-neon-pulse text-center">

                Access the Bot →
              </Link>
              <Link
                href="/guide"
                className="px-7 py-3.5 rounded-xl text-base font-bold text-white border border-[#1E2A3A] hover:border-[#00FF88]/40 hover:bg-[#00FF88]/5 transition-all duration-200 text-center">

                How It Works
              </Link>
            </div>

            {/* Mini stats row */}
            <div className="flex gap-8 pt-4 border-t border-[#1E2A3A]">
              <div>
                <span className="block text-2xl font-extrabold text-[#00FF88] font-mono">91.4%</span>
                <span className="text-xs text-[#6B7280] uppercase tracking-wider">Win Rate</span>
              </div>
              <div>
                <span className="block text-2xl font-extrabold text-white font-mono">2.4M+</span>
                <span className="text-xs text-[#6B7280] uppercase tracking-wider">Predictions</span>
              </div>
              <div>
                <span className="block text-2xl font-extrabold text-[#00D4FF] font-mono">38K</span>
                <span className="text-xs text-[#6B7280] uppercase tracking-wider">Active Users</span>
              </div>
            </div>
          </div>

          {/* Right: Prediction Card */}
          <div className="relative flex justify-center lg:justify-end">
            <div className="relative w-full max-w-sm animate-float">
              {/* Main prediction card */}
              <div className="glass-dark rounded-2xl p-6 animate-border-glow">
                {/* Card header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-2">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00FF88] opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-[#00FF88]" />
                    </span>
                    <span className="text-xs font-semibold text-[#6B7280] uppercase tracking-wider">Next Prediction</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-[#00FF88]/10 border border-[#00FF88]/20">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#00FF88" strokeWidth="2.5">
                      <circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" />
                    </svg>
                    <span className="text-xs font-bold text-[#00FF88] font-mono">{countdown < 10 ? `0${countdown}` : countdown}s</span>
                  </div>
                </div>

                {/* Big number display */}
                <div className="flex items-center justify-center mb-6">
                  <div
                    key={predIdx}
                    className={`w-28 h-28 rounded-2xl flex items-center justify-center ${colourClass[current.colour]} animate-flip-in`}
                    style={{ perspective: '400px' }}>

                    <span className="text-6xl font-extrabold font-mono">{current.number}</span>
                  </div>
                </div>

                {/* Colour badge */}
                <div className="flex items-center justify-center gap-3 mb-6">
                  <span className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold tracking-wider ${colourClass[current.colour]}`}>
                    <span className={`w-2 h-2 rounded-full ${colourDot[current.colour]}`} />
                    {current.colour}
                  </span>
                </div>

                {/* Confidence bar */}
                <div className="mb-6">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs text-[#6B7280] font-medium">Confidence Score</span>
                    <span className="text-xs font-bold text-[#00FF88]">{current.confidence}%</span>
                  </div>
                  <div className="h-2 bg-[#1E2A3A] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#00FF88] to-[#00D4FF] rounded-full transition-all duration-700"
                      style={{ width: `${current.confidence}%` }} />

                  </div>
                </div>

                {/* Divider */}
                <div className="border-t border-[#1E2A3A] pt-4">
                  <p className="text-xs text-[#6B7280] mb-3 uppercase tracking-wider font-semibold">Recent Results</p>
                  <div className="flex flex-col gap-2">
                    {HISTORY.slice(0, 3).map((h, i) =>
                    <div key={i} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className={`w-5 h-5 rounded-md flex items-center justify-center text-xs font-bold font-mono ${colourClass[h.colour]}`}>
                            {h.number}
                          </span>
                          <span className={`text-xs font-semibold ${colourClass[h.colour].split(' ')[2] || 'text-white'}`}
                        style={{ color: h.colour === 'GREEN' ? '#00FF88' : h.colour === 'RED' ? '#FF3366' : '#A75CFF' }}>
                            {h.colour}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${h.result === 'WIN' ? 'text-[#00FF88] bg-[#00FF88]/10' : 'text-[#FF3366] bg-[#FF3366]/10'}`}>
                            {h.result}
                          </span>
                          <span className="text-xs text-[#6B7280] font-mono">{h.time}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Decorative glow ring behind card */}
              <div className="absolute inset-0 -z-10 rounded-2xl bg-[#00FF88]/5 blur-2xl scale-110" />
            </div>
          </div>
        </div>
      </div>
    </section>);

}