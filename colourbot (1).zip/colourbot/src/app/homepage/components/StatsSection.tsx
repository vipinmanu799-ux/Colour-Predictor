'use client';

import React, { useEffect, useRef, useState } from 'react';

interface Stat {
  label: string;
  value: string;
  suffix: string;
  numericValue: number;
  colour: string;
  description: string;
}

const STATS: Stat[] = [
  { label: 'Win Rate', value: '91', suffix: '.4%', numericValue: 91, colour: '#00FF88', description: 'Across all prediction signals in the last 30 days' },
  { label: 'Predictions Served', value: '2.4', suffix: 'M+', numericValue: 2, colour: '#00D4FF', description: 'Total bot predictions delivered to players worldwide' },
  { label: 'Active Users', value: '38', suffix: 'K', numericValue: 38, colour: '#A75CFF', description: 'Players using ColourBot predictions daily' },
  { label: 'Accuracy Streak', value: '47', suffix: ' days', numericValue: 47, colour: '#FF3366', description: 'Consecutive days above 85% prediction accuracy' },
];

const COLOUR_ROWS = [
  { colour: 'RED', percentage: 38, count: '912K', bg: 'bg-[#FF3366]' },
  { colour: 'GREEN', percentage: 41, count: '984K', bg: 'bg-[#00FF88]' },
  { colour: 'VIOLET', percentage: 21, count: '504K', bg: 'bg-[#A75CFF]' },
];

export default function StatsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-16 px-4 sm:px-6 bg-[#080B14]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <span className="text-xs font-bold text-[#00FF88] uppercase tracking-widest block mb-3">Performance Metrics</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Numbers Don't Lie
          </h2>
          <p className="text-[#6B7280] mt-3 max-w-xl mx-auto">
            ColourBot's prediction engine is backed by live game data analysis and pattern recognition.
          </p>
        </div>

        {/* Stats bento grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          {STATS.map((stat, i) => (
            <div
              key={stat.label}
              className={`glass-dark rounded-2xl p-6 border border-[#1E2A3A] hover:border-opacity-60 transition-all duration-300 ${visible ? 'animate-slide-in-up' : 'opacity-100'}`}
              style={visible ? { animationDelay: `${i * 0.1}s` } : {}}
            >
              <div className="mb-3">
                <span className="text-xs text-[#6B7280] uppercase tracking-wider font-semibold">{stat.label}</span>
              </div>
              <div className="flex items-baseline gap-1 mb-2">
                <span className="text-4xl font-extrabold font-mono" style={{ color: stat.colour }}>
                  {stat.value}
                </span>
                <span className="text-xl font-bold" style={{ color: stat.colour }}>{stat.suffix}</span>
              </div>
              <p className="text-xs text-[#6B7280] leading-relaxed">{stat.description}</p>
            </div>
          ))}
        </div>

        {/* Colour distribution */}
        <div className="glass-dark rounded-2xl p-6 border border-[#1E2A3A]">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-6">Colour Distribution — Last 2.4M Predictions</h3>
          <div className="flex flex-col gap-4">
            {COLOUR_ROWS.map((row) => (
              <div key={row.colour} className="flex items-center gap-4">
                <span className="text-xs font-bold w-14 text-white">{row.colour}</span>
                <div className="flex-1 h-3 bg-[#1E2A3A] rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-1000 ${row.bg}`}
                    style={{ width: visible ? `${row.percentage}%` : '0%' }}
                  />
                </div>
                <span className="text-xs font-bold text-[#6B7280] w-10 text-right">{row.percentage}%</span>
                <span className="text-xs text-[#6B7280] w-12 text-right font-mono">{row.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}