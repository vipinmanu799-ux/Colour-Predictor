'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useChat } from '@/lib/hooks/useChat';
import toast from 'react-hot-toast';

interface Prediction {
  id: number;
  number: number;
  colour: 'GREEN' | 'RED' | 'VIOLET';
  confidence: number;
  time: string;
  result: 'WIN' | 'LOSS' | 'PENDING';
}

const INITIAL_PREDICTIONS: Prediction[] = [
  { id: 1, number: 3, colour: 'GREEN', confidence: 87, time: '08:31:00', result: 'WIN' },
  { id: 2, number: 7, colour: 'RED', confidence: 92, time: '08:30:30', result: 'WIN' },
  { id: 3, number: 0, colour: 'VIOLET', confidence: 78, time: '08:30:00', result: 'WIN' },
  { id: 4, number: 5, colour: 'GREEN', confidence: 84, time: '08:29:30', result: 'LOSS' },
  { id: 5, number: 8, colour: 'RED', confidence: 91, time: '08:29:00', result: 'WIN' },
  { id: 6, number: 1, colour: 'VIOLET', confidence: 76, time: '08:28:30', result: 'WIN' },
  { id: 7, number: 4, colour: 'GREEN', confidence: 89, time: '08:28:00', result: 'WIN' },
  { id: 8, number: 9, colour: 'RED', confidence: 83, time: '08:27:30', result: 'LOSS' },
];

const colourStyles: Record<string, { dot: string; text: string; bg: string }> = {
  GREEN: { dot: 'bg-[#00FF88]', text: 'text-[#00FF88]', bg: 'bg-[#00FF88]/10 border-[#00FF88]/30' },
  RED: { dot: 'bg-[#FF3366]', text: 'text-[#FF3366]', bg: 'bg-[#FF3366]/10 border-[#FF3366]/30' },
  VIOLET: { dot: 'bg-[#A75CFF]', text: 'text-[#A75CFF]', bg: 'bg-[#A75CFF]/10 border-[#A75CFF]/30' },
};

function parsePrediction(raw: string): Omit<Prediction, 'id' | 'time'> | null {
  try {
    const cleaned = raw.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(cleaned);
    const number = parseInt(parsed.number, 10);
    const colour = String(parsed.colour).toUpperCase() as 'GREEN' | 'RED' | 'VIOLET';
    const confidence = parseInt(parsed.confidence, 10);
    const result = String(parsed.result).toUpperCase() as 'WIN' | 'LOSS' | 'PENDING';
    if (
      isNaN(number) || number < 0 || number > 9 ||
      !['GREEN', 'RED', 'VIOLET'].includes(colour) ||
      isNaN(confidence) ||
      !['WIN', 'LOSS', 'PENDING'].includes(result)
    ) return null;
    return { number, colour, confidence, result };
  } catch {
    return null;
  }
}

export default function LivePredictions() {
  const [predictions, setPredictions] = useState<Prediction[]>(INITIAL_PREDICTIONS);
  const [newId, setNewId] = useState(0);
  const [aiReady, setAiReady] = useState(false);

  const { response, isLoading, error, sendMessage } = useChat('OPEN_AI', 'gpt-4.1-mini', false);

  useEffect(() => {
    if (error) toast.error('AI prediction error: ' + error.message);
  }, [error]);

  const fetchAIPrediction = useCallback(() => {
    sendMessage(
      [
        {
          role: 'system',
          content:
            'You are a colour prediction bot for a number game (0-9). Each round, predict: a number (0-9), a colour (GREEN for 1,3,7,9; RED for 2,4,6,8; VIOLET for 0,5), a confidence percentage (75-97), and a result (WIN or LOSS). Respond ONLY with valid JSON in this exact format: {"number":7,"colour":"GREEN","confidence":91,"result":"WIN"}. No explanation, no markdown, just JSON.',
        },
        {
          role: 'user',
          content: 'Generate the next prediction now.',
        },
      ],
      { max_completion_tokens: 60 }
    );
  }, [sendMessage]);

  // Trigger first AI prediction on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      setAiReady(true);
      fetchAIPrediction();
    }, 1500);
    return () => clearTimeout(timer);
  }, [fetchAIPrediction]);

  // When AI responds, add the new prediction
  useEffect(() => {
    if (!response || isLoading) return;
    const parsed = parsePrediction(response);
    if (!parsed) return;
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    const newPred: Prediction = { id: Date.now(), time: timeStr, ...parsed };
    setNewId(newPred.id);
    setPredictions((prev) => [newPred, ...prev.slice(0, 11)]);
  }, [response, isLoading]);

  // Poll AI every 30 seconds after ready
  useEffect(() => {
    if (!aiReady) return;
    const interval = setInterval(() => {
      if (!isLoading) fetchAIPrediction();
    }, 30000);
    return () => clearInterval(interval);
  }, [aiReady, isLoading, fetchAIPrediction]);

  return (
    <section className="py-16 px-4 sm:px-6 bg-[#0D1220]">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 mb-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00FF88] opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#00FF88]" />
              </span>
              <span className="text-xs font-bold text-[#00FF88] uppercase tracking-widest">Live Feed</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Real-Time Predictions
            </h2>
          </div>
          <div className="flex items-center gap-3 px-4 py-2 rounded-xl glass-dark">
            {isLoading ? (
              <>
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00D4FF] opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-[#00D4FF]" />
                </span>
                <span className="text-xs text-[#00D4FF] font-medium">AI Predicting…</span>
              </>
            ) : (
              <>
                <span className="text-xs text-[#6B7280] font-medium">AI powered · Updated every</span>
                <span className="text-xs font-bold text-[#00D4FF] font-mono">30s</span>
              </>
            )}
          </div>
        </div>

        {/* Prediction grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {predictions.slice(0, 8).map((pred) => {
            const style = colourStyles[pred.colour];
            const isNew = pred.id === newId;
            return (
              <div
                key={pred.id}
                className={`glass-dark rounded-xl p-4 border transition-all duration-500 ${
                  isNew ? 'border-[#00FF88]/60 shadow-[0_0_20px_rgba(0,255,136,0.2)]' : 'border-[#1E2A3A]'
                } ${isNew ? 'animate-slide-in-up' : ''}`}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs text-[#6B7280] font-mono">{pred.time}</span>
                  {isNew && (
                    <span className="text-[10px] font-bold text-[#00FF88] bg-[#00FF88]/10 px-1.5 py-0.5 rounded uppercase tracking-wider">New</span>
                  )}
                </div>

                <div className="flex items-center gap-3 mb-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${style.bg}`}>
                    <span className={`text-2xl font-extrabold font-mono ${style.text}`}>{pred.number}</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className={`w-2 h-2 rounded-full ${style.dot}`} />
                      <span className={`text-sm font-bold ${style.text}`}>{pred.colour}</span>
                    </div>
                    <span className="text-xs text-[#6B7280]">Confidence: <span className="text-white font-semibold">{pred.confidence}%</span></span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex-1 h-1.5 bg-[#1E2A3A] rounded-full overflow-hidden mr-3">
                    <div
                      className={`h-full rounded-full ${pred.colour === 'GREEN' ? 'bg-[#00FF88]' : pred.colour === 'RED' ? 'bg-[#FF3366]' : 'bg-[#A75CFF]'}`}
                      style={{ width: `${pred.confidence}%` }}
                    />
                  </div>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded ${pred.result === 'WIN' ? 'text-[#00FF88] bg-[#00FF88]/10' : pred.result === 'LOSS' ? 'text-[#FF3366] bg-[#FF3366]/10' : 'text-[#00D4FF] bg-[#00D4FF]/10'}`}>
                    {pred.result}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}