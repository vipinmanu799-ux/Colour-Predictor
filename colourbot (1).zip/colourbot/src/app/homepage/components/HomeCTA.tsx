import React from 'react';
import Link from 'next/link';

export default function HomeCTA() {
  return (
    <section className="py-16 px-4 sm:px-6 bg-[#0D1220]">
      <div className="max-w-4xl mx-auto">
        <div className="relative rounded-2xl overflow-hidden p-8 sm:p-12 text-center glass-dark border border-[#00FF88]/20">
          {/* Glow bg */}
          <div className="absolute inset-0 -z-10">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-48 bg-[#00FF88]/8 blur-[80px] rounded-full" />
          </div>

          <div className="flex items-center justify-center gap-2 mb-4">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00FF88] opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#00FF88]" />
            </span>
            <span className="text-xs font-bold text-[#00FF88] uppercase tracking-widest">Bot Available Now</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4">
            Ready to Start Winning?
          </h2>
          <p className="text-[#6B7280] text-lg mb-8 max-w-xl mx-auto leading-relaxed">
            Access ColourBot's live prediction feed and start making smarter colour trades today. Free to use — no signup required.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/bot-access"
              className="px-8 py-4 rounded-xl text-base font-bold text-[#080B14] bg-[#00FF88] hover:bg-[#00FF88]/90 transition-all duration-200 animate-neon-pulse w-full sm:w-auto text-center"
            >
              Get Bot Access →
            </Link>
            <Link
              href="/guide"
              className="px-8 py-4 rounded-xl text-base font-bold text-white border border-[#1E2A3A] hover:border-[#00FF88]/40 hover:bg-[#00FF88]/5 transition-all duration-200 w-full sm:w-auto text-center"
            >
              Read the Guide
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}