import React from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';

export default function Footer() {
  return (
    <footer className="border-t border-[#1E2A3A] py-8 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Logo + links */}
        <div className="flex flex-wrap items-center gap-6">
          <div className="flex items-center gap-2">
            <AppLogo size={24} iconName="BoltIcon" />
            <span className="font-bold text-sm text-white">
              Colour<span style={{ color: '#00FF88' }}>Bot</span>
            </span>
          </div>
          <Link href="/homepage" className="text-sm font-medium text-[#6B7280] hover:text-white transition-colors">Home</Link>
          <Link href="/guide" className="text-sm font-medium text-[#6B7280] hover:text-white transition-colors">Guide</Link>
          <Link href="/bot-access" className="text-sm font-medium text-[#6B7280] hover:text-white transition-colors">Bot Access</Link>
        </div>

        {/* Legal */}
        <div className="flex items-center gap-4 text-sm text-[#6B7280]">
          <span>© 2026 ColourBot</span>
          <Link href="#" className="hover:text-white transition-colors">Privacy</Link>
          <Link href="#" className="hover:text-white transition-colors">Terms</Link>
        </div>
      </div>
    </footer>
  );
}