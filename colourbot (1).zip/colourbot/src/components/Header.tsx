'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import AppLogo from '@/components/ui/AppLogo';

const navLinks = [
  { label: 'Home', href: '/homepage' },
  { label: 'Guide', href: '/guide' },
  { label: 'Bot Access', href: '/bot-access' },
];

export default function Header() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [menuOpen]);

  return (
    <>
      <header
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-[#080B14]/90 backdrop-blur-xl border-b border-[#00FF88]/10'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          {/* Logo */}
          <Link href="/homepage" className="flex items-center gap-2 group">
            <AppLogo
              size={32}
              iconName="BoltIcon"
              className="transition-all duration-300 group-hover:opacity-80"
            />
            <span className="font-bold text-lg tracking-tight text-white">
              Colour<span style={{ color: '#00FF88' }}>Bot</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks?.map((link) => {
              const isActive = pathname === link?.href || pathname === '/';
              return (
                <Link
                  key={link?.href}
                  href={link?.href}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive
                      ? 'text-[#00FF88] bg-[#00FF88]/10'
                      : 'text-[#6B7280] hover:text-white hover:bg-white/5'
                  }`}
                >
                  {link?.label}
                </Link>
              );
            })}
          </nav>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              href="/bot-access"
              className="px-5 py-2 rounded-lg text-sm font-semibold text-[#080B14] bg-[#00FF88] hover:bg-[#00FF88]/90 transition-all duration-200 animate-neon-pulse"
            >
              Get Bot Access
            </Link>
          </div>

          {/* Hamburger */}
          <button
            className="md:hidden p-2 text-white"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            {menuOpen ? (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M18 6L6 18M6 6l12 12" />
              </svg>
            ) : (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            )}
          </button>
        </div>
      </header>
      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-40 bg-[#080B14]/95 backdrop-blur-xl flex flex-col justify-center items-center transition-all duration-500 md:hidden ${
          menuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <nav className="flex flex-col items-center gap-6">
          {navLinks?.map((link) => (
            <Link
              key={link?.href}
              href={link?.href}
              onClick={() => setMenuOpen(false)}
              className="text-3xl font-bold text-white hover:text-[#00FF88] transition-colors tracking-tight"
            >
              {link?.label}
            </Link>
          ))}
          <Link
            href="/bot-access"
            onClick={() => setMenuOpen(false)}
            className="mt-4 px-8 py-3 rounded-xl text-lg font-bold text-[#080B14] bg-[#00FF88] animate-neon-pulse"
          >
            Get Bot Access
          </Link>
        </nav>
      </div>
    </>
  );
}